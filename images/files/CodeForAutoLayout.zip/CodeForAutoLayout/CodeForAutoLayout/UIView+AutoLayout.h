//
//  UIView+AutoLayout.h
//  CodeForAutoLayout
//
//  Created by Zacks Tsang  on 13-11-28.
//  Copyright (c) 2013年 www.aiysea.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (AutoLayout)
+(instancetype)autoLayoutView;
@end
