//
//  CodeAutoLayoutView.m
//  CodeForAutoLayout
//
//  Created by Zacks Tsang  on 13-11-28.
//  Copyright (c) 2013年 www.aiysea.com. All rights reserved.
//

#import "CodeAutoLayoutView.h"

@implementation CodeAutoLayoutView{

    NSLayoutConstraint *tempConstraint;

}

- (id)init
{
    self = [super init];
    if (self) {
        [self initView];
    }
    return self;
}

-(void)initView{
    
    UILabel *lblTitle=[UILabel autoLayoutView];
    lblTitle.text=@"Code For AutoLayOut";
    lblTitle.backgroundColor=[UIColor brownColor];
    
    [self addSubview:lblTitle];

    //普通frame
    [self tlwh:lblTitle andFrame:CGRectMake(20, 30, 250, 23)];
    
    double delayInSeconds = 2.0;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        lblTitle.numberOfLines=0;
        lblTitle.text=@"Runtime System对于Objective-C来说就好比是它的操作系统，或者说是运行的支撑平台，它使得Objective-C代码能够按照既定的语言特性跑起来。相对于C/C++来说，Objective-C尽可能地把一些动作推迟到运行时来执行，即尽可能动态地做事情。因此，它不仅需要一个编译器，还需要一个运行时环境来执行编译后的代码。即父类的成员变量的布局发生改变时，子类不需要重新编译。此外，还支持为声明的属性进行合成操作（即@property和@synthesis）。";
        
        [lblTitle sizeToFit];
        
        [self layoutIfNeeded];
    });
    
    
    //与父view边缘
//    [self tlbr:lblTitle andEdge:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    
    //屏幕的中心
//    [self wh:lblTitle andSize:CGSizeMake(250, 23)];
//    [self centerInX:lblTitle];
//    [self centerInY:lblTitle];
    
//    UIView *sub1=[UIView autoLayoutView];
//    sub1.backgroundColor=[UIColor purpleColor];
//    [self addSubview:sub1];
//    
//    [self wh:sub1 andSize:CGSizeMake(150, 200)];
//    
//    [self addConstraint:[NSLayoutConstraint constraintWithItem:sub1 attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:lblTitle attribute:NSLayoutAttributeLeft multiplier:1.0 constant:0]];
//    
//    [self addConstraint:[NSLayoutConstraint constraintWithItem:sub1 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lblTitle attribute:NSLayoutAttributeBottom multiplier:1.0 constant:20]];
//    
//    
//    UIView *sub2=[UIView autoLayoutView];
//    sub2.backgroundColor=[UIColor blueColor];
//    [self addSubview:sub2];
//    
//    
//    
//    UIView *sub11=[UIView autoLayoutView];
//    sub11.backgroundColor=[UIColor greenColor];
//    [sub1 addSubview:sub11];
//
//    [self wh:sub11 andSize:CGSizeMake(50, 50)];
//    
//    
//    [sub1 addConstraint:[NSLayoutConstraint constraintWithItem:sub11 attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:sub1 attribute:NSLayoutAttributeLeft multiplier:1.0 constant:20]];
//    
//    [self addConstraint:[NSLayoutConstraint constraintWithItem:sub11 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:sub2 attribute:NSLayoutAttributeBottom multiplier:1.0 constant:0]];
//    
//    
//    [self wh:sub2 andSize:CGSizeMake(50, 20)];
//    
//    
//    [self addConstraint:[NSLayoutConstraint constraintWithItem:sub2 attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:sub1 attribute:NSLayoutAttributeTrailing multiplier:1.0 constant:20]];
//    
//    [self addConstraint:[NSLayoutConstraint constraintWithItem:sub2 attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:lblTitle attribute:NSLayoutAttributeBottom multiplier:1.0 constant:50]];
    
    
    //easy for animation
//    double delayInSeconds = 2.0;
//    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
//    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
//        
//        tempConstraint.constant=150;
//        
//        [UIView animateWithDuration:0.35 animations:^{
//            
//            [self layoutIfNeeded];
//            
//        } completion:^(BOOL finished) {
//            
//        }];
//        
//    });
}

/**
 NSLayoutAttributeBaseline        底线
 
 NSLayoutAttributeBottom          底部
 
 NSLayoutAttributeCenterX         X轴中点
 
 NSLayoutAttributeCenterY         Y轴中点
 
 NSLayoutAttributeLeading         头
 
 NSLayoutAttributeLeft            左
 
 NSLayoutAttributeRight           右
 
 NSLayoutAttributeTop             顶部
 
 NSLayoutAttributeTrailing        尾
 
 NSLayoutAttributeWidth           宽
 
 NSLayoutAttributeHeight          高
 
 NSLayoutAttributeNotAnAttribute  0 没属性
*/

-(void)centerInX:(UIView *)view{
    
    NSMutableArray *constraints=[NSMutableArray arrayWithCapacity:3];
    
    NSLayoutConstraint *constraint=[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
    
    [constraints addObject:constraint];
    
    [self addConstraints:constraints];
}

-(void)centerInY:(UIView *)view{
    
    NSMutableArray *constraints=[NSMutableArray arrayWithCapacity:3];
    
    NSLayoutConstraint *constraint=[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0];
    
    [constraints addObject:constraint];
    
    [self addConstraints:constraints];
}

-(void)tlwh:(UIView *)view andFrame:(CGRect)frame{
    
    NSMutableArray *constraints=[NSMutableArray arrayWithCapacity:3];
    
    NSLayoutConstraint *constraint=[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:frame.origin.x];
    
    [constraints addObject:constraint];
    
    constraint=[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.0 constant:frame.origin.y];
    
    tempConstraint=constraint;
    
    [constraints addObject:constraint];
    
    [self addConstraints:constraints];
    
    [self wh:view andSize:frame.size];
    
}

-(void)wh:(UIView *)view andSize:(CGSize)size{

    [view addConstraint:[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:0 multiplier:0 constant:size.width]];
    
    
//    NSLayoutConstraint *constraint=[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:0 multiplier:0 constant:size.height];
//    tempConstraint=constraint;
//    
//    [view addConstraint:constraint];
    
}

-(void)tlbr:(UIView *)view andEdge:(UIEdgeInsets)padding{
    
    NSMutableArray *constraints=[NSMutableArray arrayWithCapacity:3];
    
    NSLayoutConstraint *constraint=[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeft multiplier:1.0 constant:padding.top];
    
    [constraints addObject:constraint];
    
    constraint=[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.0 constant:padding.left];
    
    [constraints addObject:constraint];
    
    constraint=[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1.0 constant:padding.right];
    
    [constraints addObject:constraint];
    
    constraint=[NSLayoutConstraint constraintWithItem:view attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1.0 constant:padding.bottom];
    
    
    [constraints addObject:constraint];
    
    [self addConstraints:constraints];
}

@end
