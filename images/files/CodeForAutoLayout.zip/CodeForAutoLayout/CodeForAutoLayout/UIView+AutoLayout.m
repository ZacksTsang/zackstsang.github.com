//
//  UIView+AutoLayout.m
//  CodeForAutoLayout
//
//  Created by Zacks Tsang  on 13-11-28.
//  Copyright (c) 2013年 www.aiysea.com. All rights reserved.
//

#import "UIView+AutoLayout.h"

@implementation UIView (AutoLayout)

+(instancetype)autoLayoutView
{
    UIView *view = [[self alloc] init];
    view.translatesAutoresizingMaskIntoConstraints = NO;
    return view;
}



@end
